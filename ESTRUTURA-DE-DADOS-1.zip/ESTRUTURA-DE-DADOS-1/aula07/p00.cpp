#include <iostream>
#include <stack>

